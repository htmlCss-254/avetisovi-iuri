let cel = prompt("enter c°:");

let far = (Number(cel) * 9 / 5) + 32;

alert("your f°: " + far);


const title = document.querySelector('p'); 
title.textContent = "hello world"