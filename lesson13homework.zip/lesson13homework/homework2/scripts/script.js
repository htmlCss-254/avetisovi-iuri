const prompt = require('prompt-sync')();

let name = prompt("Enter your name: ");
alert("hello " + name);

let age = prompt("Enter your age: ");

if (Number(age) >= 18) {
    alert("you are adult");
} else {
    alert("you are not adult");
}
